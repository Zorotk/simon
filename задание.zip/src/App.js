import React, {useState} from "react";
import "./App.css";
import Content from "./content/content";
import Slider from "react-slick";
import slide1 from './content/slide1.png'
import slide2 from './content/slide2.png'
import Feedback from "./components/feedback/feedback";
import Categories from "./components/Categories/Categories";
import Tabs from "./components/tabs/tabs";

function App() {
    let tabs = [
        {
            title: (
                <div>
                    <label htmlFor={"tab1"}> tab 1</label>
                    <input name="tabName" id="tab1" type="radio"/>
                </div>
            ),
            content: "content 1"
        },
        {
            title: (
                <div>
                    <label htmlFor={"tab2"}> tab 2</label>
                    <input name="tabName" id="tab2" type="radio"/>
                </div>
            ),
            content: "content 2"
        },
        {
            title: (
                <div>
                    <label htmlFor={"tab3"}> tab 3</label>
                    <input name="tabName" id="tab3" type="radio"/>
                </div>
            ),
            content: <Categories/>
        }
    ];
    const [activeTab, setactiveTab] = useState(2);
    const [feedback, setfeedback] = useState(false)
    const [onCategories, setonCategories] = useState(false)
    var settings = {
        autoplay: true,
        arrows: true,
        dots: false,
        fade: true,
        infinite: true,
        autoplaySpeed: 4000,
        slidesToShow: 1,
        slidesToScroll: 1,
        adaptiveHeight: true,
    };
    const onClose = () => {
        setfeedback(false)
    }

    if (onCategories) {
        return <Tabs tabs={tabs} activeTab={activeTab} onChoiceTab={setactiveTab}/>
    }

    return (
        <div className={'app'}>

            <header>

                <div className={'title-company'}>
                    <div className={'title-name'}>
                        <div onClick={() => {
                            setonCategories(true)
                        }} className={'box'}></div>
                        <div className={'box-title-name'}>
                            <div className={'title-name-company'}>
                                <div>Название</div>
                                <div>компании</div>
                            </div>
                            <div>самая клевая компания</div>
                        </div>
                    </div>
                    <div className={'title-phone'}>
                        <div className={'title-phone-num'}>+7(499) 777-77-77</div>
                        <div className={'title-phone-num'}>+7(499) 777-77-77</div>
                        <div onClick={() => setfeedback(true)} className={'call'}>Обратная связь</div>
                    </div>
                </div>
            </header>

            <nav className={"menu"}>
                <ul className={'menu-links'}>
                    <li><a href="#">Главная</a></li>
                    <li><a href="#">Каталог</a></li>
                    <li><a href="#">Доставка и оплата</a></li>
                    <li><a href="#">Прайс-лист</a></li>
                    <li><a href="#">Контакты</a></li>
                </ul>
            </nav>
            <div className={'slider'}>
                <Slider {...settings}>
                    <div>
                        <img src={slide1} alt=""/>
                    </div>
                    <div>
                        <img src={slide2} alt=""/>
                    </div>

                </Slider>
            </div>

            <Content/>
            <div className={'pagination'}>
                <div>1</div>
                <div>2</div>
                <div className={"btnActive"}>3</div>
                <div>4</div>
                <div>5</div>
                <div>6</div>
                <div>7</div>
            </div>
            <div className={'context-info'}>
                <div>
                    Иными словами, рондо преобразует шоу-бизнес. Непосредственно из законов сохранения следует, что
                    рондо многопланово позволяет исключить из рассмотрения колебательный фузз, рассматривая уравнения
                    движения тела в проекции на касательную к его траектории. Установившийся режим характеризует
                    определенный угол курса. Угловая скорость, обобщая изложенное, вероятна. Как уже указывалось,
                    арпеджированная фактура многопланово определяет флэнжер.
                </div>
                <div>Субтехника, в соответствии с основным законом динамики, регрессийно определяет динамический
                    эллипсис. Open-air, в соответствии с модифицированным уравнением Эйлера, использует небольшой
                    флэнжер. Динамическое уравнение Эйлера одновременно. Механическая система не входит своими
                    составляющими, что очевидно, в силы нормальных реакций связей, так же как и момент сил. Эти слова
                    совершенно справедливы, однако проекция фактурна. Отсутствие трения, в том числе, искажает
                    устойчивый подвижный объект.
                </div>
            </div>
            <footer>
                <div>
                    <div>
                        © 2014–2019 ЗАО «Компания»
                    </div>
                    <div>info@name.ru</div>
                </div>


                <div className={'footer-menu'}>
                    <div>Главная</div>
                    <div>Каталог</div>
                    <div>Доставка</div>
                    <div>Прайс-лист</div>
                    <div>Контакты</div>
                </div>
                <div>
                    <div>Разработка сайта — IT-компания «Нефабрика»</div>
                    <div>IT-компания «Нефабрика»</div>
                </div>


            </footer>
            <div className={'feedback '}>
                {feedback && <Feedback onClose={onClose}/>}
            </div>
        </div>
    )
}

export default App;
