import React, {useState} from 'react';
import './Categories.css'
import EditFoto from "../editFoto/editFoto";
import Tabs from "../tabs/tabs";

let currentDate = new Date().toISOString().substring(0, 10);
const Categories = ({
                        // tabs, activeTab, onChoiceTab
}) => {
    const [chekTime, setchekTime] = useState(true)
    const [arrTarif, setarrTarif] = useState([])
    const [changeSelect, setchangeSelect] = useState('')
    const [editFoto, seteditFoto] = useState(false)
    const [changeName, setchangeName] = useState('')
    const [objselect, setobjselect] = useState(
        [{
            name: 'tariff'
        }]);
    const [arrRadioBtn, setarrRadioBtn] = useState(['tab1', 'tab2', 'tab3'])
    const [checkRadioBtn, setcheckRadioBtn] = useState([false, false, true])

    function onChangeSelect(e) {
        setchangeSelect(e.target.value)
    }

    function onName() {
        objselect.push({name: changeName})
        setchangeName('')
    }

    function changeNames(e) {
        setchangeName(e.target.value)
    }

    function onAddTarif() {
        arrTarif.push(changeSelect)
        setarrTarif([...arrTarif])
    }

    function onDelitTariff(index) {
        let test = arrTarif.filter((_, i) => i !== index)
        setarrTarif(test)
    }

    function choiceTab(i) {
        checkRadioBtn[i] = !checkRadioBtn[i]
        setcheckRadioBtn([...checkRadioBtn])
    }

    if (editFoto) {
        return <EditFoto/>
    }

    return (
        <div className={'Categories'}>
            <div>название</div>
            <input value={changeName} onChange={changeNames} type="text"/>
            <button onClick={onName}>add</button>
            <div>
                <div className={'service'}>
                    <div>
                        <div>услуги</div>
                        <input type="text"/>
                    </div>
                    <div>
                        <div>категории</div>
                        <input type="text"/>
                    </div>
                </div>
                <div>
                    <div>описание</div>
                    <textarea name="" id="" cols="30" rows="10">
                </textarea></div>
                <div>превью</div>
                <div className={'categor-description'}>
                    <div onClick={() => {
                        seteditFoto(true)
                    }}>+
                    </div>
                </div>
                <div>
                    <div>price</div>
                    <input type="text"/>
                    <div>currency</div>
                    <input type="number"/>
                    <div>
                        <select className={'select'}
                                value={objselect.name}
                                onChange={(e) => onChangeSelect(e)}
                                name="test" id="1">
                            {objselect.map((option, i) => {
                                return <option value={option.name} key={option.name + i}>
                                    {option.name}
                                </option>
                            })
                            }
                        </select>
                        <button onClick={onAddTarif}>добавить</button>
                    </div>
                    <div>
                        {arrTarif.map((tarif, i) => {
                            return (
                                <div key={i}>
                                    <div>{tarif}
                                        <input type="checkbox" id="subscribeNews" name="subscribe" checked={chekTime}
                                               onChange={() => setchekTime(!chekTime)}/>
                                        <label htmlFor="subscribeNews">Time valid</label>

                                        <input type="date" id="start" name="trip-start"

                                               value={currentDate}
                                        />
                                        <input type="date" id="start" name="trip-start"
                                               disabled={chekTime ? true : false}/>
                                        <input type="checkbox" id="Week day" name="subscribe"
                                               disabled={chekTime ? true : false} checked={chekTime}
                                               onChange={() => setchekTime(!chekTime)}/>
                                        <label htmlFor="Week day">Week day</label>
                                        <button onClick={() => onDelitTariff(i)}>x</button>
                                    </div>
                                </div>
                            )
                        })}
                    </div>

                </div>
                <button>Отправить</button>
            </div>
        </div>
    );
};

export default Categories;