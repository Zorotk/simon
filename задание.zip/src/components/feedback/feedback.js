import React, {useState, useEffect} from 'react';
import './feedback.css'
import x from './x.png'

const Feedback = ({onClose}) => {
    const [form, setform] = useState({})
    const [validForm, setvalidForm] = useState(false)
    const [inputArr, setinputArr] = useState(['Ваше имя *', 'Телефон *', 'Email *'])
    const formHandler = (e) => {
        e.preventDefault()
    }
    useEffect(() => {
        setvalidForm(inputArr.every((name) => form[name]))
    }, [form])

    return (
        <div className={'feedback'}>
            <div className={'modal'}>
                <div>
                    <div className={'modal-exit'}>
                        <img onClick={onClose} className={'exit-img'} src={x} alt=""/>
                    </div>


                    <div className="modal-body">
                        <form action="" onSubmit={formHandler}>
                            <h2 className={'model-title'}>Обратная связь</h2>
                            {inputArr.map((el, i) => (
                                    <div className={'input-form'} key={i}>
                                        <div>{el}</div>
                                        <input
                                            value={form[el] || ""}
                                            onChange={(e) => setform({...form, [el]: e.target.value})}
                                            className={'modal-input'} type="text"/>
                                    </div>
                                )
                            )}
                            <div>Сообщение</div>
                            <textarea className={'modal-area'} name="" id="" cols="30" rows="10">
                    </textarea>
                            <div>{validForm ? "" : "Поля с * обязательно для заполнения"}</div>
                            <button className={'btnModal'}>Отправить</button>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    );
};

export default Feedback;