import React from 'react';
import './tabs.css'
const Tabs = ({onChoiceTab, tabs, activeTab}) => {
    console.log(activeTab)
    return (
        <div>
            <div className={'tab-content'}>
                <div className="tab-btns">
                    {tabs.map((tab, i) => (
                        <div className="tab-btn" key={i} onClick={()=>onChoiceTab(i)}>{tab.title}</div>
                    ))}
                </div>
            </div>
            <div className={activeTab!==2?'tab-content':''}>{tabs[activeTab].content}</div>
        </div>
    );
};

export default Tabs;