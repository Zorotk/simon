import React,{useEffect, useState} from 'react';
import {useDropzone} from 'react-dropzone';
import './editFoto.css'

const thumbsContainer = {
    display: 'flex',
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 16
};

const thumb = {
    display: 'inline-flex',
    borderRadius: 2,
    border: '1px solid #eaeaea',
    marginBottom: 8,
    marginRight: 8,
    width: 100,
    height: 100,
    padding: 4,
    boxSizing: 'border-box'
};

const thumbInner = {
    display: 'flex',
    minWidth: 0,
    overflow: 'hidden'
};

const img = {
    display: 'block',
    width: 'auto',
    height: '100%'
};


function Previews({onChange}) {
    const [files, setFiles] = useState([]);

    console.log(files)
    const {getRootProps, getInputProps} = useDropzone({
        accept: 'image/*',
        onDrop: acceptedFiles => {
            setFiles(acceptedFiles.map(file => Object.assign(file, {
                preview: URL.createObjectURL(file)
            })));
            onChange(acceptedFiles)
        }


    });

    const thumbs = files.map(file => (
        <div style={thumb} key={file.name}>
            <div style={thumbInner}>
                <img
                    src={file.preview}
                    style={img}
                />
            </div>
        </div>
    ));

    useEffect(() => () => {
        // Make sure to revoke the data uris to avoid memory leaks
        files.forEach(file => URL.revokeObjectURL(file.preview));
    }, [files]);

    return (
        <section className="container">
            <div {...getRootProps({className: 'dropzone'})}>
                <input {...getInputProps()} />
                <div className={'edit-box'}>
                    +
                </div>
            </div>
            <aside style={thumbsContainer}>
                {thumbs}
            </aside>
        </section>
    );
}

function sendToServer() {
    return new Promise((resolve => resolve('ok')))
}

const EditFoto = () => {
    const [arrImage, setarrImage] = useState([])
    const sendFile = () => {
        var formData = new FormData();
        formData.append('files', arrImage);
        sendToServer('http://server.com/api/upload', {
            method: 'POST',
            body: formData
        })
    }
    const onChange = (value) => {
        setarrImage(value)

    }
    return (
        <div className={'EditFoto'}>
            <input type="file" id="input" multiple/>

            <Previews onChange={onChange}/>
            <button onClick={sendFile}>send</button>
        </div>
    );
};

export default EditFoto;