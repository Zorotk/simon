import React from 'react';
import './content.css'
import image from './nophoto.jpg'
import imageCart from "./image/addtobasket_mini.png"

const Content = () => {
    return (
        <div className={'content-wrapper'}>
            <main className={' content '}>
                <div className={'content-bar'}>
                    <ul>Главная</ul>
                    <ul>Каталог</ul>
                    <ul>Бытовая техника</ul>
                </div>
                <div className={'content-block'}>
                    <div className="left-block">
                        <ul>Автомобили</ul>
                        <ul className={'left-block-active'}>Автомобили</ul>
                        <ul>
                            <li className={'block-active'}>Микроволновки</li>
                            <li> Холодильники</li>
                            <li>Посудомойки</li>
                            <li>Чайник</li>
                        </ul>
                        <ul>Автомобили</ul>
                        <ul>Автомобили</ul>
                        <ul>Автомобили</ul>
                        <ul>Автомобили</ul>
                    </div>
                    <div className="center-block">
                        <div className={'content-card'}>
                            <img src={image} className={'image-card'} alt=""/>
                            <div className={'description'}>
                                Самый клевый чайник, который надо купить!
                            </div>
                            <div className="card-foter">
                                <b>1 900 р.</b>
                                <img className="fit-picture" src={imageCart} alt="imageCart"/>
                            </div>
                        </div>
                        <div className={'content-card'}>
                            <img src={image} className={'image-card'} alt=""/>
                            <div className={'description'}>
                                Самый клевый чайник, который надо купить!
                            </div>
                            <div className="card-foter">
                                <b>1 900 р.</b>
                                <img className="fit-picture" src={imageCart} alt="imageCart"/>
                            </div>
                        </div>
                        <div className={'content-card'}>
                            <img src={image} className={'image-card'} alt=""/>
                            <div className={'description'}>
                                Самый клевый чайник, который надо купить!
                            </div>
                            <div className="card-foter">
                                <b>1 900 р.</b>
                                <img className="fit-picture" src={imageCart} alt="imageCart"/>
                            </div>
                        </div>
                        <div className={'content-card'}>
                            <img src={image} className={'image-card'} alt=""/>
                            <div className={'description'}>
                                Самый клевый чайник, который надо купить!
                            </div>
                            <div className="card-foter">
                                <b>1 900 р.</b>
                                <img className="fit-picture" src={imageCart} alt="imageCart"/>
                            </div>
                        </div>
                        <div className={'content-card'}>
                            <img src={image} className={'image-card'} alt=""/>
                            <div className={'description'}>
                                Самый клевый чайник, который надо купить!
                            </div>
                            <div className="card-foter">
                                <b>1 900 р.</b>
                                <img className="fit-picture" src={imageCart} alt="imageCart"/>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default Content;